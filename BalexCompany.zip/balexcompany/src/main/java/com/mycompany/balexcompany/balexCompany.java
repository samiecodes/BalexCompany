/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.balexcompany;

/**
 *
 * @author jordan
 */
public class balexCompany {
     // Constants
    private static final double MINIMUM_WAGE = 8.00;
    private static final int MAX_HOURS = 60;
    private static final int REGULAR_HOURS = 40;
    private static final double OVERTIME_RATE = 1.5;

    // Method to calculate and print the total pay or an error message
    public static void calculatePay(double basePay, int hoursWorked) {
        if (basePay < MINIMUM_WAGE) {
            System.out.println("Error: The base pay of $" + basePay + " is below the minimum wage of $" + MINIMUM_WAGE + " per hour.");
            return;
        }

        if (hoursWorked > MAX_HOURS) {
            System.out.println("Error: The number of hours worked (" + hoursWorked + ") exceeds the maximum allowed (" + MAX_HOURS + ").");
            return;
        }

        double totalPay = 0;

        if (hoursWorked <= REGULAR_HOURS) {
            totalPay = hoursWorked * basePay;
        } else {
            int overtimeHours = hoursWorked - REGULAR_HOURS;
            totalPay = (REGULAR_HOURS * basePay) + (overtimeHours * basePay * OVERTIME_RATE);
        }

        System.out.println("Total pay for " + hoursWorked + " hours at $" + basePay + " per hour is: $" + totalPay);
    }

    // Main method
    public static void main(String[] args) {
        // Test cases with the given employees
        calculatePay(7.50, 35);   // Employee 1
        calculatePay(8.20, 47);   // Employee 2
        calculatePay(10.00, 73);  // Employee 3
    }
}
